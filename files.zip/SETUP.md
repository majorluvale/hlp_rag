# HLP Intelligence Hub — Observabilité avec Langfuse

## Pourquoi Langfuse ?

Langfuse est **gratuit** (open-source + cloud gratuit jusqu'à 50K traces/mois).
Il te permet de :
- 📊 **Tracer** chaque conversation et appel LLM
- ✏️  **Annoter et corriger** les réponses sans toucher au code
- ⭐ **Scorer** les réponses (précision, pertinence, sécurité)
- 📝 **Ajouter des datasets** d'évaluation (Q&R validés)
- 🔁 **Comparer des prompts** via le Prompt Management

---

## 1. Créer un compte gratuit

→ https://cloud.langfuse.com/auth/sign-up

Ou auto-héberger (Docker) :
```bash
git clone https://github.com/langfuse/langfuse
cd langfuse
docker compose up -d
# Accès : http://localhost:3000
```

---

## 2. Variables d'environnement

Dans ton fichier `.env` ou Streamlit Cloud Secrets :

```env
GROQ_API_KEY=gsk_...
LANGFUSE_PUBLIC_KEY=pk-lf-...
LANGFUSE_SECRET_KEY=sk-lf-...
LANGFUSE_BASE_URL=https://cloud.langfuse.com   # ou ton URL auto-hébergée
```

Sur **Streamlit Cloud** : Settings → Secrets → coller le contenu TOML :
```toml
GROQ_API_KEY = "gsk_..."
LANGFUSE_PUBLIC_KEY = "pk-lf-..."
LANGFUSE_SECRET_KEY = "sk-lf-..."
LANGFUSE_BASE_URL = "https://cloud.langfuse.com"
```

---

## 3. Ce que tu peux faire dans le dashboard Langfuse

### Évaluer une réponse
1. Ouvre une trace dans Langfuse
2. Clique "Add Score"
3. Choisis un critère : `correctness`, `relevance`, `safety`, `helpfulness`
4. Note de 0 à 1 + commentaire optionnel

### Corriger une réponse (Human Feedback)
1. Dans la trace, clique "Add Annotation"
2. Tape la réponse idéale
3. Ces annotations alimentent ton dataset d'évaluation

### Gérer les prompts sans redeployer
1. Langfuse → "Prompt Management" → "New Prompt"
2. Colle ton system prompt et sauvegarde
3. Dans le code, remplace la ligne `prompt = PromptTemplate.from_template(...)` par :

```python
from langfuse import Langfuse
lf = Langfuse()
prompt_obj = lf.get_prompt("hlp-system-prompt")  # nom dans le dashboard
prompt = PromptTemplate.from_template(prompt_obj.prompt)
```

Ainsi, **modifier le prompt dans le dashboard = effet immédiat**, sans redéployer.

### Créer un dataset d'évaluation
1. Langfuse → "Datasets" → "Create Dataset" → nom: `hlp-eval`
2. Ajoute des paires Input/Output validés
3. Lance des evals automatiques via l'API Langfuse

---

## 4. Installation

```bash
pip install -r requirements.txt
```

## 5. Lancement

```bash
streamlit run hlp_agent.py
```

---

## 6. Outils disponibles dans l'agent

| Outil | Source | Description |
|---|---|---|
| `hlprag` | Chroma local | Base vectorielle HLP |
| `get_hlp_planning_data` | OCHA HPC API | PIN, Targeted, Reached, Funding |
| `search_hlp_resources` | GPC + NRC | Documents et ressources HLP |
| `search_reliefweb` | ReliefWeb API | Rapports humanitaires récents |
| `scrape_hpc_learning` | HPC Collective Learning | Leçons apprises, bonnes pratiques |
| `fetch_webpage_content` | Web (allowlist) | Lecture de pages/documents |
| `search_iom_ifrc` | IOM + IFRC | Ressources des agences leaders |

---

## 7. Architecture

```
User Question
    │
    ▼
Streamlit UI (hlp_agent.py)
    │
    ▼
Agent (LangChain RunnableWithMessageHistory)
    │
    ├──► hlprag (Chroma Vector Store)
    ├──► get_hlp_planning_data (OCHA HPC API)
    ├──► search_hlp_resources (GPC/NRC scraper)
    ├──► search_reliefweb (ReliefWeb API)
    ├──► scrape_hpc_learning (OCHA scraper)
    ├──► fetch_webpage_content (URL fetcher)
    └──► search_iom_ifrc (IOM/IFRC scraper)
    │
    ▼
Langfuse (trace + evaluation + prompt management)
```
